from django.contrib import admin
from accounts.models import MyUser, Employee

# Register your models here.
admin.site.register(MyUser)
admin.site.register(Employee)






