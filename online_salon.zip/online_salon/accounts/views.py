from django.shortcuts import render
from .models import Employee

from django.views import generic
from accounts.models import MyUser
from accounts.forms import UserCreationForm

# Create your views here.
class SignUp(generic.CreateView):
    model = MyUser
    form_class = UserCreationForm
    template_name = "accounts/sign_up.html"
    succcess_url = "accounts/login"
    
    
class ProfilePage(generic.TemplateView):
    model = MyUser
    template_name = "accounts/profile.html"
    
    
class ThanksPage(generic.TemplateView):
    template_name = "accounts/thanks.html"
    

class EmployeeList(generic.ListView):
    model = Employee
    template_name = 'accounts/employee_list.html'
    
    
    
    
    
    
    