from django.http import HttpResponse
from .models import Product, Transaction
from django.shortcuts import render,get_object_or_404
from django import forms
from django.views import generic
from django.contrib.auth import get_user_model
from django.urls import reverse_lazy
User = get_user_model()

from .forms import TransactionForm

# mixins 
class TransactionMixin(object):
    model = Transaction
    form_class = TransactionForm
    template_name = 'inventory/transac_form.html'
    success_url = reverse_lazy('inventory:all')
    

# Create your views here.
class ProductList(generic.ListView):
    model = Product
    template_name = 'inventory/product_list.html'


class ProductDetail(generic.DetailView):
    model = Product
    template_name = 'inventory/product_detail.html'
    

class TransactionList(generic.ListView):
    model = Transaction
    template_name = 'inventory/transac_list.html'


class TransactionDetail(generic.DetailView):
    model = Transaction
    template_name = 'inventory/transac_detail.html'


class TransactionAdd(TransactionMixin, generic.CreateView):
    pass


class TransactionUpdate(TransactionMixin, generic.UpdateView):
    pass


class TransactionDelete(generic.DeleteView):
    model = Transaction
    template_name = 'inventory/transac_delete.html'
    success_url = reverse_lazy('inventory:all')
    

def details(request,item_id):
	item = get_object_or_404(Product, pk=prduct_id)
	clients = User.objects.all()
	return render(request,'details.html',{'item':item,'clients':clients})

def transferitm(request,item_id):
	client = User.objects.get(place=request.POST.get("client"))
	item = Item.objects.get(pk=item_id)
	quantity = request.POST.get("quantity")
	transaction=Transaction(quantity=quantity,item=item,client=client)
	transaction.save()
	item.quantity = item.quantity-int(quantity)
	item.save()
	return render(request,'transferitm.html',{'transaction':transaction,'quantity':quantity,'item':item,'client':client})

def returnitm(request,item_id):
	client = User.objects.get(place=request.POST.get("client"))
	item = Item.objects.get(pk=item_id)
	quantity = request.POST.get("quantity")
	transaction = Transaction(quantity=quantity,item=item,client=client)
	transaction.save()
	item.quantity = item.quantity+int(quantity)
	item.save()
	return render(request,'returnitm.html',{'transaction':transaction,'quantity':quantity,'item':item,'client':client})
	
	
	
	
	
	
	
	
	
	
	