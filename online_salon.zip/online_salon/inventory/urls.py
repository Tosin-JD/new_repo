from django.urls import path

from . import views

app_name = 'inventory'

urlpatterns=[
    path('', views.TransactionList.as_view(), name='all'),
	path('<int:pk>/transaction', views.TransactionDetail.as_view(), name='trans_detail'),
	path('add/', views.TransactionAdd.as_view(), name='add'),
	path('<int:pk>/transaction-edit/', views.TransactionUpdate.as_view(), name='trans_edit'),
	path('<int:pk>/transaction-delete/', views.TransactionDelete.as_view(), name='trans_delete'),
	path('products/', views.ProductList.as_view(), name='pr_list'),
	path('<int:pk>/product/', views.ProductDetail.as_view(), name='pr_detail'),
	path('<int:product_id>/', views.details, name='details'),
	path('<int:product_id>/transfer', views.transferitm, name='transferitm'),
	path('<int:product_id>/return', views.returnitm, name='returnitm'),
]

