from django.forms import ModelForm

from .models import Transaction


class TransactionForm(ModelForm):
    
    def __init__(self, **kwargs):
        super(TransactionForm, self).__init__(**kwargs)
        self.fields['client'].widget.attrs['class'] = 'form-control my-1'
        self.fields['product'].widget.attrs['class'] = 'form-control my-1'
        self.fields['quantity'].widget.attrs['class'] = 'form-control my-1'
    
    class Meta:
        model = Transaction
        fields = ('product', 'client', 'quantity')



