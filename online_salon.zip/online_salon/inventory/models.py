
from django.db import models
from django.contrib.auth import get_user_model

# this is django default user
User = get_user_model()


# Create your models here.

class Category(models.Model):
	name = models.CharField(max_length=50)
	
	class Meta:
	    verbose_name_plural = 'Categories'
	
	def __str__(self):
		return self.name
	

class Product(models.Model):
	name = models.CharField(max_length=50)
	category = models.ForeignKey(Category,on_delete=models.CASCADE)
	quantity = models.IntegerField(default=0)
	description = models.TextField(null=True, blank=True)
	image = models.ImageField(upload_to='products/')
	
	def __str__(self):
		return self.name


class Transaction(models.Model):
	quantity = models.IntegerField(default=1)
	time = models.DateTimeField(auto_now=True)
	product = models.ForeignKey(Product,on_delete=models.CASCADE,blank=False,null=False)
	client = models.ForeignKey(User,on_delete=models.CASCADE,blank=False,null=False)
	
	def __str__(self):
		return ("%s , %s , %s" % (self.product.name, self.client, self.time))











