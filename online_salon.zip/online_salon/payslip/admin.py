from django.contrib import admin
from .models import (Employee,
                     Payment,
                     PaymentType)

# Register your models here.
admin.site.register(Employee)
admin.site.register(Payment)
admin.site.register(PaymentType)





