"""Views for the ``online_docs`` app."""
from datetime import datetime
import os

from django.contrib.auth.decorators import login_required
from django.shortcuts import reverse
from django.db.models import Q, Sum
from django.http import Http404, HttpResponse
from django.utils.decorators import method_decorator
from django.views.generic import (
    CreateView,
    DeleteView,
    FormView,
    TemplateView,
    UpdateView,
)

from services.models import (AnimatedIntro,
                    Service,
                    WelcomeNote)


from dateutil import relativedelta, rrule
# uncomment on system
# from weasyprint import HTML, CSS

# from .app_settings import CURRENCY
from .forms import (
    PaymentForm,
    PayslipForm,
)
from .models import (
    Employee,
    Payment,
    PaymentType,
)


# -------------#
# Mixins       #
# -------------#

class PermissionMixin(object):
    """Mixin to handle security functions."""
    @method_decorator(login_required)
    def dispatch(self, request, *args, **kwargs):
        """
        Makes sure that the user is logged in and has the right to display this
        view.
        """
        if not request.user.is_staff:
            raise Http404
        return super(PermissionMixin, self).dispatch(request, *args, **kwargs)

    def get_success_url(self):
        return reverse('payslip_dashboard')


class PaymentMixin(object):
    """Mixin to handle payment related functions."""
    model = Payment
    form_class = PaymentForm


class PaymentTypeMixin(object):
    """Mixin to handle payment type related functions."""
    model = PaymentType
    fields = '__all__'


# -------------#
# Views        #
# -------------#

class HomePage(TemplateView):
    template_name = 'index.html'
    model = Service
    
    def get_context_data(self, **kwargs):
        context = super(HomePage, self).get_context_data(**kwargs)
        context['intro_list'] = AnimatedIntro.objects.all()
        context['welcomenotes'] = WelcomeNote.objects.all()[:3]
        return context
        


class AboutPage(TemplateView):
    template_name = 'about.html'


class DashboardView(PermissionMixin, TemplateView):
    """Dashboard to navigate through the payslip app."""
    template_name = 'payslip/dashboard.html'

    def get_context_data(self, **kwargs):
        return {
            'employees': Employee.objects.all(),
            'payments': Payment.objects.all(),
            'payment_types': PaymentType.objects.all(),
        }


class PaymentTypeCreateView(PaymentTypeMixin,
                            CreateView):
    """Classic view to create a payment type."""
    pass


class PaymentTypeUpdateView(PaymentTypeMixin,
                            UpdateView):
    """Classic view to update a payment type."""
    pass


class PaymentTypeDeleteView(PaymentTypeMixin,
                            DeleteView):
    """Classic view to delete a payment type."""
    pass


class PaymentCreateView(PaymentMixin, CreateView):
    """Classic view to create a payment."""
    pass


class PaymentUpdateView(PaymentMixin, UpdateView):
    """Classic view to update a payment."""
    pass


class PaymentDeleteView(PaymentMixin, DeleteView):
    """Classic view to delete a payment."""
    pass

"""
class PayslipGeneratorView(FormView):
    #View to present a small form to generate a custom payslip.
    template_name = 'payslip/payslip_form.html'
    form_class = PayslipForm

    def get_form_kwargs(self):
        kwargs = super(PayslipGeneratorView, self).get_form_kwargs()
        kwargs.update({'company': self.company})
        return kwargs

    def get_template_names(self):
        if hasattr(self, 'post_data'):
            return ['payslip/payslip.html']
        return super(PayslipGeneratorView, self).get_template_names()

    def get_context_data(self, **kwargs):
        kwargs = super(PayslipGeneratorView, self).get_context_data(**kwargs)
        if hasattr(self, 'post_data'):
            # Get form data
            employee = Employee.objects.get(pk=self.post_data.get('employee'))
            self.date_start = datetime.strptime(
                '{}-{}-01'.format(
                    self.post_data.get('year'), self.post_data.get('month')),
                '%Y-%m-%d',
            )
            january_1st = datetime.strptime(
                '{}-01-01'.format(self.post_data.get('year')),
                '%Y-%m-%d',
            )
            date_end = self.date_start + relativedelta.relativedelta(
                months=1) - relativedelta.relativedelta(days=1)

            # Get payments for the selected year
            payments_year = employee.payments.filter(
                # Recurring payments with past date and end_date in the
                # selected year or later
                Q(date__lte=date_end, end_date__gte=january_1st) |
                # Recurring payments with past date in period and open end
                Q(date__lte=date_end, end_date__isnull=True,
                  payment_type__rrule__isnull=False)
            ).exclude(
                payment_type__rrule__exact='') | employee.payments.filter(
                # Single payments in this year
                date__year=self.date_start.year, payment_type__rrule__exact='',
            )

            # Get payments for the selected period
            payments = payments_year.exclude(
                # Exclude single payments not transferred in the period
                Q(date__lt=self.date_start) |
                Q(date__gt=date_end),
                Q(payment_type__rrule__exact=''),
            ).filter(
                # Recurring payments with past date and end_date in the period
                Q(end_date__gte=date_end, date__lte=date_end) |
                # Recurring payments with past date in period and open end
                Q(date__lte=date_end, end_date__isnull=True)
            )

            # Yearly positive summary
            sum_year = payments_year.filter(
                amount__gt=0, payment_type__rrule__exact='').aggregate(
                    Sum('amount')).get('amount__sum') or 0

            # Yearly negative summary
            sum_year_neg = payments_year.filter(
                amount__lt=0, payment_type__rrule__exact='').aggregate(
                    Sum('amount')).get('amount__sum') or 0

            # Yearly summary of recurring payments
            for payment in payments_year.exclude(
                    payment_type__rrule__exact=''):
                # If the recurring payment started in a year before, let's take
                # January 1st as a start, otherwise take the original date
                if payment.get_date_without_tz().year < self.date_start.year:
                    start = january_1st
                else:
                    start = payment.get_date_without_tz()
                # If the payments ends before the period's end date, let's take
                # this date, otherwise we can take the period's end
                if (payment.end_date and
                        payment.get_end_date_without_tz() < date_end):
                    end = payment.get_end_date_without_tz()
                else:
                    end = date_end
                recurrings = rrule.rrule(
                    rrule._rrulestr._freq_map.get(payment.payment_type.rrule),
                    dtstart=start, until=end,
                )
                # Multiply amount with recurrings
                if payment.amount > 0:
                    sum_year += payment.amount * recurrings.count()
                else:
                    sum_year_neg += payment.amount * recurrings.count()

            # Period summaries
            sum = payments.filter(amount__gt=0).aggregate(
                Sum('amount')).get('amount__sum') or 0
            sum_neg = payments.filter(amount__lt=0).aggregate(
                Sum('amount')).get('amount__sum') or 0

            kwargs.update({
                'employee': employee,
                'date_start': self.date_start,
                'date_end': date_end,
                'payments': payments,
                'payment_extra_fields': ExtraFieldType.objects.filter(
                    model='Payment'),
                'sum_year': sum_year,
                'sum_year_neg': sum_year + sum_year_neg,
                'sum': sum,
                'sum_neg': sum_neg,
                'currency': CURRENCY,
            })
        return kwargs

    def form_valid(self, form):
        self.post_data = self.request.POST
        if 'download' in self.post_data:
            html = self.render_to_response(self.get_context_data(form=form))
            f = open(os.path.join(
                os.path.dirname(__file__), './static/payslip/css/payslip.css'))
            html = HTML(string=html.render().content)
            pdf = html.write_pdf(stylesheets=[CSS(string=f.read())])
            f.close()
            resp = HttpResponse(pdf, content_type='application/pdf')
            resp['Content-Disposition'] = \
                u'attachment; filename="{}_{}.pdf"'.format(
                    self.date_start.year, self.date_start.month)
            return resp
        return self.render_to_response(self.get_context_data(form=form))
        """
        








