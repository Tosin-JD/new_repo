""" payslip.urls"""
from django.conf.urls import url

from .views import (
    DashboardView,
    PaymentCreateView,
    PaymentDeleteView,
    PaymentUpdateView,
    PaymentTypeCreateView,
    PaymentTypeDeleteView,
    PaymentTypeUpdateView,
    #PayslipGeneratorView,
)

app_name = 'payslip'


urlpatterns = [
    url(r'^$',
        DashboardView.as_view(),
        name='dashboard',
        ),

    url(r'^payment/create/$',
        PaymentCreateView.as_view(),
        name='payslip_payment_create',
        ),

    url(r'^payment/(?P<pk>\d+)/update/$',
        PaymentUpdateView.as_view(),
        name='payslip_payment_update',
        ),

    url(r'^payment/(?P<pk>\d+)/delete/$',
        PaymentDeleteView.as_view(),
        name='payslip_payment_delete',
        ),

    url(r'^payment-type/create/$',
        PaymentTypeCreateView.as_view(),
        name='payslip_payment_type_create',
        ),

    url(r'^payment-type/(?P<pk>\d+)/update/$',
        PaymentTypeUpdateView.as_view(),
        name='payslip_payment_type_update',
        ),

    url(r'^payment-type/(?P<pk>\d+)/delete/$',
        PaymentTypeDeleteView.as_view(),
        name='payslip_payment_type_delete',
        ),

    # url(r'^payslip/$',
    #    PayslipGeneratorView.as_view(),
    #    name='payslip_generator',
    #    ),
]

